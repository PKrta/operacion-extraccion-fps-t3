﻿# Operación Extracción: Sobrevive al Apocalipsis (FPS 3D)

## Descripción del Juego
Videojuego tridimensional de disparos en primera persona (FPS) donde el jugador debe atravesar una calle nocturna infestada de zombis, administrar su munición entre dos armas distintas, recolectar cajas de suministros y llegar con vida a la zona segura de extracción.

## Dependencias y Tecnologías
* **Entorno:** Visual Studio 2022 (.NET / ASP.NET Core para servidor estático de modelos `.glb`).
* **Motor Gráfico:** WebGL / Three.js v0.160.0 (cargado automáticamente vía CDN `importmap` en `index.html`, no requiere instalación manual de paquetes `npm`).
* **Complementos:** `PointerLockControls` y `GLTFLoader`.

## Instrucciones de Instalación y Ejecución
**Opción A — Desde Visual Studio 2022:**
1. Clonar o descomprimir el repositorio.
2. Abrir el archivo de solución (`.sln`) en **Visual Studio 2022**.
3. Presionar **F5** (o el botón **https**) para levantar el servidor local y abrir el juego en el navegador.

**Opción B — Desde Visual Studio Code o Python (sin Visual Studio 2022):**
1. Abrir la carpeta `wwwroot` del proyecto.
2. Ejecutar con la extensión **Live Server** sobre `index.html` o correr en terminal `python -m http.server 8000` e ingresar a `http://localhost:8000`.

## Controles
* **W, A, S, D:** Desplazarse hacia adelante, izquierda, atrás y derecha.
* **Movimiento del Mouse:** Orientar la cámara en primera persona.
* **Tecla 1:** Seleccionar Arma 1 (Pistola Táctica).
* **Tecla 2:** Seleccionar Arma 2 (Rifle de Asalto).
* **Clic Izquierdo:** Disparar una vez (disparo único semiautomático).

## Fuentes y Créditos de Recursos Externos
* **Pistola (`arma1.glb`):** "Pistol" por **Zsky** — Obtenido en [Poly Pizza](https://poly.pizza/m/3To2e7sKmO) (Licencia CC-BY 3.0).
* **Rifle de Asalto (`arma2.glb`):** "Assault Rifle" por **Quaternius** — Obtenido en [Poly Pizza](https://poly.pizza/m/Bgvuu4CUMV) (Licencia CC0 / Dominio público).
* **Zombi (`zombi.glb`):** "Zombie" por **bachosoftdesign** — Obtenido en [Poly Pizza](https://poly.pizza/m/xqEzosAVYX) (Licencia CC-BY 3.0).
* **Texturas del entorno:** Generadas proceduralmente por código mediante HTML5 Canvas (`createAsphaltTexture`, `createBrickTexture`, `createCrateTexture`).