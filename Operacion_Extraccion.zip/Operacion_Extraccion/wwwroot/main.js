﻿import * as THREE from 'three';
import { PointerLockControls } from 'three/addons/controls/PointerLockControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b0e14);
scene.fog = new THREE.FogExp2(0x0b0e14, 0.018);

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.05, 250);
camera.position.set(0, 1.7, 0);
scene.add(camera);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
document.body.appendChild(renderer.domElement);

const ambientLight = new THREE.AmbientLight(0x8899bb, 0.55);
scene.add(ambientLight);

const dirLight = new THREE.DirectionalLight(0xcce0ff, 0.9);
dirLight.position.set(20, 45, 15);
dirLight.castShadow = true;
scene.add(dirLight);

function createAsphaltTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#1e2226';
    ctx.fillRect(0, 0, 512, 512);
    for (let i = 0; i < 6000; i++) {
        const v = 25 + Math.floor(Math.random() * 25);
        ctx.fillStyle = `rgb(${v},${v},${v})`;
        ctx.fillRect(Math.random() * 512, Math.random() * 512, 2, 2);
    }
    ctx.fillStyle = '#d4a017';
    ctx.fillRect(248, 0, 16, 260);
    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(3, 18);
    return tex;
}

function createBrickTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#2b2d30';
    ctx.fillRect(0, 0, 256, 256);
    const rows = 8;
    const cols = 4;
    const bh = 256 / rows;
    const bw = 256 / cols;
    for (let r = 0; r < rows; r++) {
        const offset = (r % 2) * (bw / 2);
        for (let c = -1; c <= cols; c++) {
            const shade = 65 + Math.floor(Math.random() * 25);
            ctx.fillStyle = `rgb(${shade + 18}, ${shade}, ${shade - 8})`;
            ctx.fillRect(c * bw + offset + 2, r * bh + 2, bw - 4, bh - 4);
        }
    }
    const tex = new THREE.CanvasTexture(canvas);
    tex.wrapS = THREE.RepeatWrapping;
    tex.wrapT = THREE.RepeatWrapping;
    return tex;
}

function createCrateTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#5c4028';
    ctx.fillRect(0, 0, 256, 256);
    ctx.strokeStyle = '#382414';
    ctx.lineWidth = 6;
    for (let i = 0; i < 256; i += 32) {
        ctx.beginPath();
        ctx.moveTo(0, i);
        ctx.lineTo(256, i);
        ctx.stroke();
    }
    ctx.lineWidth = 14;
    ctx.strokeRect(8, 8, 240, 240);
    ctx.beginPath();
    ctx.moveTo(8, 8);
    ctx.lineTo(248, 248);
    ctx.moveTo(248, 8);
    ctx.lineTo(8, 248);
    ctx.stroke();
    return new THREE.CanvasTexture(canvas);
}

const asphaltTex = createAsphaltTexture();
const brickTex = createBrickTexture();
const crateTex = createCrateTexture();

const controls = new PointerLockControls(camera, document.body);
const overlay = document.getElementById('overlay');
const overlayTitle = document.getElementById('overlay-title');
const overlayMsg = document.getElementById('overlay-msg');
const weaponNameEl = document.getElementById('weapon-name');
const ammoCountEl = document.getElementById('ammo-count');

let gameState = 'PAUSED';
const moveKeys = { KeyW: false, KeyS: false, KeyA: false, KeyD: false };

overlay.addEventListener('click', () => {
    if (gameState === 'PAUSED') controls.lock();
    else if (gameState === 'GAMEOVER' || gameState === 'VICTORY') location.reload();
});

controls.addEventListener('lock', () => {
    if (gameState !== 'GAMEOVER' && gameState !== 'VICTORY') {
        gameState = 'PLAYING';
        overlay.style.display = 'none';
    }
});

controls.addEventListener('unlock', () => {
    if (gameState === 'PLAYING') {
        gameState = 'PAUSED';
        overlay.style.display = 'flex';
        overlayTitle.textContent = 'PAUSA';
        overlayMsg.textContent = 'Haz clic para continuar la misión.';
    }
});

const gltfLoader = new GLTFLoader();
let currentWeapon = 1;

const weapons = {
    1: { name: '1 - Pistola Táctica', ammo: 8, mesh: new THREE.Group() },
    2: { name: '2 - Rifle de Asalto', ammo: 5, mesh: new THREE.Group() }
};

const muzzleLight = new THREE.PointLight(0xffaa22, 0, 8);
muzzleLight.position.set(0.25, -0.15, -0.9);
camera.add(muzzleLight);

const muzzleFlashMesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.055, 8, 8),
    new THREE.MeshBasicMaterial({ color: 0xffdd44 })
);
muzzleFlashMesh.position.set(0.28, -0.2, -0.85);
muzzleFlashMesh.visible = false;
camera.add(muzzleFlashMesh);

function fitWeaponModel(model, targetLength, flipDirection = false) {
    const initialBox = new THREE.Box3().setFromObject(model);
    const initialSize = new THREE.Vector3();
    initialBox.getSize(initialSize);

    if (initialSize.x > initialSize.z) {
        model.rotation.y = flipDirection ? Math.PI / 2 : -Math.PI / 2;
    } else {
        model.rotation.y = flipDirection ? Math.PI : 0;
    }

    const maxDim = Math.max(initialSize.x, initialSize.y, initialSize.z) || 1;
    const scale = targetLength / maxDim;
    model.scale.setScalar(scale);

    model.updateMatrixWorld(true);
    const scaledBox = new THREE.Box3().setFromObject(model);
    const center = new THREE.Vector3();
    scaledBox.getCenter(center);
    model.position.sub(center);
}

function setupWeapons() {
    weapons[1].mesh.position.set(0.28, -0.24, -0.45);
    weapons[2].mesh.position.set(0.28, -0.22, -0.5);
    weapons[2].mesh.visible = false;

    camera.add(weapons[1].mesh);
    camera.add(weapons[2].mesh);

    gltfLoader.load('./assets/models/arma1.glb', (gltf) => {
        const model = gltf.scene;
        fitWeaponModel(model, 0.32, false);
        weapons[1].mesh.add(model);
    }, undefined, () => {
        const fallback1 = new THREE.Mesh(
            new THREE.BoxGeometry(0.08, 0.12, 0.3),
            new THREE.MeshStandardMaterial({ color: 0x3388ff })
        );
        weapons[1].mesh.add(fallback1);
    });

    gltfLoader.load('./assets/models/arma2.glb', (gltf) => {
        const model = gltf.scene;
        fitWeaponModel(model, 0.55, true);
        weapons[2].mesh.add(model);
    }, undefined, () => {
        const fallback2 = new THREE.Mesh(
            new THREE.BoxGeometry(0.1, 0.14, 0.55),
            new THREE.MeshStandardMaterial({ color: 0xff8800 })
        );
        weapons[2].mesh.add(fallback2);
    });
}
setupWeapons();

function updateHUD() {
    weaponNameEl.textContent = weapons[currentWeapon].name;
    ammoCountEl.textContent = weapons[currentWeapon].ammo;
}

function switchWeapon(index) {
    currentWeapon = index;
    weapons[1].mesh.visible = (index === 1);
    weapons[2].mesh.visible = (index === 2);
    updateHUD();
}

const obstacles = [];
const environmentMeshes = [];

const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(36, 130),
    new THREE.MeshStandardMaterial({ map: asphaltTex, roughness: 0.85 })
);
floor.rotation.x = -Math.PI / 2;
floor.position.z = -50;
floor.receiveShadow = true;
scene.add(floor);
environmentMeshes.push(floor);

function createSidewalk(x) {
    const sw = new THREE.Mesh(
        new THREE.BoxGeometry(4, 0.25, 130),
        new THREE.MeshStandardMaterial({ color: 0x55595e, roughness: 0.9 })
    );
    sw.position.set(x, 0.125, -50);
    sw.receiveShadow = true;
    scene.add(sw);
    environmentMeshes.push(sw);
}
createSidewalk(-10.5);
createSidewalk(10.5);

function createWall(x, y, z, w, h, d, isCrate = false) {
    let mat;
    if (isCrate) {
        mat = new THREE.MeshStandardMaterial({ map: crateTex, roughness: 0.7 });
    } else {
        const tex = brickTex.clone();
        tex.needsUpdate = true;
        tex.repeat.set(Math.max(1, Math.round(Math.max(w, d) / 3)), Math.max(1, Math.round(h / 3)));
        mat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.85 });
    }
    const wall = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
    wall.position.set(x, y, z);
    wall.castShadow = true;
    wall.receiveShadow = true;
    scene.add(wall);
    obstacles.push(new THREE.Box3().setFromObject(wall));
    environmentMeshes.push(wall);
}

createWall(-12.5, 4, -50, 1, 8, 130, false);
createWall(12.5, 4, -50, 1, 8, 130, false);
createWall(0, 4, 12, 26, 8, 1, false);
createWall(0, 4, -110, 26, 8, 1, false);

createWall(-4, 1.4, -20, 7, 2.8, 2.2, true);
createWall(4, 1.4, -45, 7, 2.8, 2.2, true);
createWall(-3, 1.4, -70, 8, 2.8, 2.2, true);

function createStreetLamp(x, z) {
    const pole = new THREE.Mesh(
        new THREE.CylinderGeometry(0.1, 0.14, 5.5, 8),
        new THREE.MeshStandardMaterial({ color: 0x222222, metalness: 0.7 })
    );
    pole.position.set(x, 2.75, z);
    scene.add(pole);

    const bulb = new THREE.Mesh(
        new THREE.SphereGeometry(0.28, 12, 12),
        new THREE.MeshBasicMaterial({ color: 0xffe0a0 })
    );
    bulb.position.set(x > 0 ? x - 0.8 : x + 0.8, 5.4, z);
    scene.add(bulb);

    const light = new THREE.PointLight(0xffbb66, 6, 22);
    light.position.copy(bulb.position);
    scene.add(light);
}

createStreetLamp(-9, -10);
createStreetLamp(9, -35);
createStreetLamp(-9, -60);
createStreetLamp(9, -85);

function createStars() {
    const geo = new THREE.BufferGeometry();
    const pts = [];
    for (let i = 0; i < 400; i++) {
        pts.push(
            (Math.random() - 0.5) * 200,
            25 + Math.random() * 60,
            (Math.random() - 0.5) * 200 - 40
        );
    }
    geo.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
    const stars = new THREE.Points(
        geo,
        new THREE.PointsMaterial({ color: 0xffffff, size: 0.35 })
    );
    scene.add(stars);
}
createStars();

const extractionPosition = new THREE.Vector3(0, 0.1, -95);
const extractionZone = new THREE.Mesh(
    new THREE.CylinderGeometry(3.5, 3.5, 0.25, 32),
    new THREE.MeshStandardMaterial({ color: 0x00ff66, emissive: 0x00aa44 })
);
extractionZone.position.copy(extractionPosition);
scene.add(extractionZone);

const extractionLight = new THREE.PointLight(0x00ff66, 8, 18);
extractionLight.position.set(0, 2.5, -95);
scene.add(extractionLight);

const ammoBoxes = [];
function spawnAmmoBox(x, z, amount = 6) {
    const box = new THREE.Mesh(
        new THREE.BoxGeometry(0.85, 0.6, 0.85),
        new THREE.MeshStandardMaterial({ color: 0xffcc00, emissive: 0x553300, roughness: 0.4 })
    );
    box.position.set(x, 0.4, z);
    box.userData = { amount, active: true };
    scene.add(box);
    ammoBoxes.push(box);
}

spawnAmmoBox(-6, -25, 6);
spawnAmmoBox(6, -55, 6);
spawnAmmoBox(0, -80, 8);

const zombies = [];
const zombieMeshes = [];

function spawnZombie(x, z, detectionRange = 18, speed = 3.2) {
    const container = new THREE.Group();
    container.position.set(x, 0, z);
    const innerGroup = new THREE.Group();
    container.add(innerGroup);

    container.userData = {
        hp: 2,
        alive: true,
        detectionRange,
        speed,
        innerGroup,
        walkOffset: Math.random() * Math.PI * 2,
        mixer: null,
        walkAction: null
    };

    gltfLoader.load('./assets/models/zombi.glb', (gltf) => {
        const model = gltf.scene;

        const box = new THREE.Box3().setFromObject(model);
        const size = new THREE.Vector3();
        box.getSize(size);
        const maxDim = Math.max(size.x, size.y, size.z) || 1;
        const scale = 1.85 / maxDim;
        model.scale.setScalar(scale);

        model.updateMatrixWorld(true);
        const newBox = new THREE.Box3().setFromObject(model);
        const center = new THREE.Vector3();
        newBox.getCenter(center);
        model.position.x -= center.x;
        model.position.z -= center.z;
        model.position.y -= newBox.min.y;

        model.traverse((child) => {
            if (child.isMesh) {
                child.material = child.material.clone();
                child.castShadow = true;
                child.frustumCulled = false;
                child.userData.zombieRoot = container;
                zombieMeshes.push(child);
            }
        });

        if (gltf.animations && gltf.animations.length > 0) {
            let selectedClip = gltf.animations.find(
                (clip) => /walk|run/i.test(clip.name) && !/crawl|crouch/i.test(clip.name)
            );
            if (!selectedClip) {
                selectedClip = gltf.animations[0];
            }

            const inPlaceClip = selectedClip.clone();
            inPlaceClip.tracks = inPlaceClip.tracks.filter(
                (track) => !track.name.endsWith('.position')
            );

            const mixer = new THREE.AnimationMixer(model);
            const action = mixer.clipAction(inPlaceClip);
            action.play();
            container.userData.mixer = mixer;
            container.userData.walkAction = action;
        }

        innerGroup.add(model);
    }, undefined, () => {
        const body = new THREE.Mesh(
            new THREE.CapsuleGeometry(0.45, 1.0, 4, 8),
            new THREE.MeshStandardMaterial({ color: 0x3a7d44 })
        );
        body.position.y = 1.0;
        body.userData.zombieRoot = container;
        innerGroup.add(body);
        zombieMeshes.push(body);
    });

    scene.add(container);
    zombies.push(container);
}

spawnZombie(2, -18, 15, 2.8);
spawnZombie(-5, -35, 16, 3.2);
spawnZombie(5, -40, 16, 3.4);
spawnZombie(-2, -62, 18, 3.6);
spawnZombie(4, -66, 18, 3.6);
spawnZombie(0, -86, 20, 4.0);

const activeParticles = [];
const activeTracers = [];

function createBulletTracer(startPos, endPos) {
    const distance = startPos.distanceTo(endPos);
    const geometry = new THREE.CylinderGeometry(0.012, 0.012, distance, 6);
    geometry.translate(0, distance / 2, 0);
    geometry.rotateX(Math.PI / 2);

    const material = new THREE.MeshBasicMaterial({
        color: 0xffee55,
        transparent: true,
        opacity: 0.9
    });

    const tracer = new THREE.Mesh(geometry, material);
    tracer.position.copy(startPos);
    tracer.lookAt(endPos);
    scene.add(tracer);
    activeTracers.push({ mesh: tracer, life: 0.09 });
}

function createImpactParticles(point, colorHex) {
    for (let i = 0; i < 10; i++) {
        const p = new THREE.Mesh(
            new THREE.BoxGeometry(0.06, 0.06, 0.06),
            new THREE.MeshBasicMaterial({ color: colorHex })
        );
        p.position.copy(point);
        const velocity = new THREE.Vector3(
            (Math.random() - 0.5) * 5,
            Math.random() * 4 + 1,
            (Math.random() - 0.5) * 5
        );
        scene.add(p);
        activeParticles.push({ mesh: p, velocity, life: 0.35 });
    }
}

const raycaster = new THREE.Raycaster();

window.addEventListener('mousedown', (e) => {
    if (gameState !== 'PLAYING' || e.button !== 0) return;

    const weapon = weapons[currentWeapon];
    if (weapon.ammo <= 0) return;

    weapon.ammo -= 1;
    updateHUD();

    weapon.mesh.position.z += 0.07;
    muzzleLight.intensity = 5;
    muzzleFlashMesh.visible = true;
    setTimeout(() => {
        weapon.mesh.position.z -= 0.07;
        muzzleLight.intensity = 0;
        muzzleFlashMesh.visible = false;
    }, 75);

    const muzzleWorldPos = new THREE.Vector3();
    muzzleFlashMesh.getWorldPosition(muzzleWorldPos);

    raycaster.setFromCamera(new THREE.Vector2(0, 0), camera);
    const allTargets = [...zombieMeshes, ...environmentMeshes];
    const hits = raycaster.intersectObjects(allTargets, true);

    let targetPoint = new THREE.Vector3();
    camera.getWorldDirection(targetPoint);
    targetPoint.multiplyScalar(60).add(camera.position);

    if (hits.length > 0) {
        targetPoint = hits[0].point;
        const hitMesh = hits[0].object;
        const zombieRoot = hitMesh.userData.zombieRoot;

        if (zombieRoot && zombieRoot.userData.alive) {
            createImpactParticles(targetPoint, 0xbb1111);
            zombieRoot.userData.hp -= 1;

            zombieRoot.userData.innerGroup.traverse((child) => {
                if (child.isMesh && child.material && child.material.color) {
                    child.material.color.setHex(0xcc2222);
                }
            });

            if (zombieRoot.userData.hp <= 0) {
                zombieRoot.userData.alive = false;
                if (zombieRoot.userData.walkAction) {
                    zombieRoot.userData.walkAction.reset();
                    zombieRoot.userData.walkAction.stop();
                }
                if (zombieRoot.userData.mixer) {
                    zombieRoot.userData.mixer.update(0);
                }
                zombieRoot.userData.innerGroup.position.set(0, 0.2, 0);
                zombieRoot.userData.innerGroup.rotation.set(-Math.PI / 2, 0, 0);
            }
        } else {
            createImpactParticles(targetPoint, 0xffcc44);
        }
    }

    createBulletTracer(muzzleWorldPos, targetPoint);
});

window.addEventListener('keydown', (e) => {
    if (e.code in moveKeys) moveKeys[e.code] = true;
    if (e.key === '1') switchWeapon(1);
    if (e.key === '2') switchWeapon(2);
});

window.addEventListener('keyup', (e) => {
    if (e.code in moveKeys) moveKeys[e.code] = false;
});

function endGame(title, message, state) {
    gameState = state;
    controls.unlock();
    overlay.style.display = 'flex';
    overlayTitle.textContent = title;
    overlayMsg.textContent = message + ' (Haz clic para reiniciar)';
}

const clock = new THREE.Clock();

function animate() {
    requestAnimationFrame(animate);
    const delta = clock.getDelta();
    const elapsed = clock.getElapsedTime();

    if (gameState === 'PLAYING') {
        const speed = 6.5 * delta;
        const prevPos = camera.position.clone();

        if (moveKeys.KeyW) controls.moveForward(speed);
        if (moveKeys.KeyS) controls.moveForward(-speed);
        if (moveKeys.KeyD) controls.moveRight(speed);
        if (moveKeys.KeyA) controls.moveRight(-speed);

        const playerBox = new THREE.Box3().setFromCenterAndSize(
            camera.position,
            new THREE.Vector3(0.8, 1.8, 0.8)
        );
        for (const wallBox of obstacles) {
            if (playerBox.intersectsBox(wallBox)) {
                camera.position.copy(prevPos);
                break;
            }
        }

        for (let i = activeTracers.length - 1; i >= 0; i--) {
            activeTracers[i].life -= delta;
            activeTracers[i].mesh.material.opacity = Math.max(0, activeTracers[i].life * 10);
            if (activeTracers[i].life <= 0) {
                scene.remove(activeTracers[i].mesh);
                activeTracers.splice(i, 1);
            }
        }

        for (let i = activeParticles.length - 1; i >= 0; i--) {
            const p = activeParticles[i];
            p.life -= delta;
            p.velocity.y -= 9.8 * delta;
            p.mesh.position.addScaledVector(p.velocity, delta);
            if (p.life <= 0) {
                scene.remove(p.mesh);
                activeParticles.splice(i, 1);
            }
        }

        for (const box of ammoBoxes) {
            if (!box.userData.active) continue;
            box.rotation.y += 1.8 * delta;
            box.position.y = 0.4 + Math.sin(elapsed * 3) * 0.08;
            const boxDist = Math.hypot(
                box.position.x - camera.position.x,
                box.position.z - camera.position.z
            );
            if (boxDist < 1.5) {
                box.userData.active = false;
                box.visible = false;
                weapons[currentWeapon].ammo += box.userData.amount;
                updateHUD();
            }
        }

        for (const zombie of zombies) {
            if (!zombie.userData.alive) continue;

            const dist = Math.hypot(
                zombie.position.x - camera.position.x,
                zombie.position.z - camera.position.z
            );

            if (dist < 1.2) {
                endGame('GAME OVER', 'Has sido atrapado por un zombi.', 'GAMEOVER');
                return;
            }

            if (dist <= zombie.userData.detectionRange) {
                const target = new THREE.Vector3(camera.position.x, zombie.position.y, camera.position.z);
                zombie.lookAt(target);
                const dir = new THREE.Vector3().subVectors(target, zombie.position).normalize();
                zombie.position.addScaledVector(dir, zombie.userData.speed * delta);

                if (zombie.userData.mixer) {
                    zombie.userData.mixer.update(delta);
                }
                const cycle = elapsed * 8 + zombie.userData.walkOffset;
                zombie.userData.innerGroup.position.y = Math.abs(Math.sin(cycle)) * 0.05;
            } else {
                zombie.userData.innerGroup.position.y = 0;
                zombie.userData.innerGroup.rotation.set(0, 0, 0);
            }
        }

        const distToExit = Math.hypot(
            camera.position.x - extractionPosition.x,
            camera.position.z - extractionPosition.z
        );
        if (distToExit < 3.2) {
            endGame(
                '¡MISIÓN COMPLETADA!',
                '¡MISIÓN COMPLETADA! Has llegado a la zona de extracción.',
                'VICTORY'
            );
        }
    }

    renderer.render(scene, camera);
}
animate();

window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
});